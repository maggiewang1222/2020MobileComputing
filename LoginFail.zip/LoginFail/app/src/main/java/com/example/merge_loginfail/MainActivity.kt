package com.example.merge_loginfail


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Build;

import android.annotation.SuppressLint;
import android.content.ClipData
import android.content.Context
import android.content.Intent

//import android.support.v7.app.AppCompatActivity
import android.view.*
import android.widget.*

import androidx.annotation.RequiresApi
import kotlinx.android.synthetic.main.activity_main.*

import android.view.View
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    lateinit var etFirstName: EditText
    lateinit var etLastName: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bind()
        viewInitializations()


        button.setOnClickListener {
//            Toast.makeText(this, "Hello word!", Toast.LENGTH_SHORT).show()
            val intent = Intent()

            intent.setClass(this, MainActivity2::class.java)

            startActivity(intent)

        }

    }

    private fun bind() {
        addQuestions()
        addAnswers()
    }
    fun viewInitializations() {

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    fun validateInput(): Boolean {
        if (etFirstName.text.toString().equals("")) {
            etFirstName.setError("Please Enter First Name")
            return false
        }
        if (etLastName.text.toString().equals("")) {
            etLastName.setError("Please Enter Last Name")
            return false
        }

        return true
    }

    fun performSignUp (view: View) {
        if (validateInput()) {

            val firstName = etFirstName.text.toString()
            val lastName = etLastName.text.toString()
            Toast.makeText(this,"Login Success", Toast.LENGTH_SHORT).show()

        }

    }
    @SuppressLint("InflateParams")
    private fun addQuestions() {
        val inflater = getSystemService(
                Context.LAYOUT_INFLATER_SERVICE
        ) as LayoutInflater
        for (i in 1..6) {
            val view = inflater.inflate(R.layout.item_question, null)
            view.setOnDragListener(DragListener())
            questionContainer.addView(view)
        }
    }


    @SuppressLint("InflateParams")
    fun addAnswers() {
        val inflater = getSystemService(
                Context.LAYOUT_INFLATER_SERVICE
        ) as LayoutInflater

        val view = inflater.inflate(R.layout.item_answer, null)
        view.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(view)

        val viewtwo = inflater.inflate(R.layout.item_answer_2, null)
        viewtwo.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(viewtwo)

        val viewthr = inflater.inflate(R.layout.item_answer_3, null)
        viewthr.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(viewthr)

        val viewfou = inflater.inflate(R.layout.item_answer_4, null)
        viewfou.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(viewfou)

        val viewfiv = inflater.inflate(R.layout.item_answer_5, null)
        viewfiv.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(viewfiv)

        val viewsix = inflater.inflate(R.layout.item_answer_6, null)
        viewsix.setOnTouchListener(DragItemTouchListener())
        answerContainer.addView(viewsix)

    }


    //val ITEM_INDEX_D = "Index-From"
    private inner class DragItemTouchListener : View.OnTouchListener {

        @RequiresApi(Build.VERSION_CODES.N)
        override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
            return if (motionEvent.action == MotionEvent.ACTION_DOWN) {
                dragMultiple(view)
                true
            } else {
                false
            }
        }

        @RequiresApi(Build.VERSION_CODES.N)
        private fun dragMultiple(view: View) {
            val data = ClipData.newPlainText("11", "11")
            val shadowBuilder = View.DragShadowBuilder(
                    view
            )
            val parent = view.parent as ViewGroup

            view.startDragAndDrop(data, shadowBuilder, view, 0)
            parent.removeView(view)
        }
    }

    private class DragListener : View.OnDragListener {


        override fun onDrag(v: View, event: DragEvent): Boolean {
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {

                }
                DragEvent.ACTION_DRAG_ENTERED -> {

                }
                DragEvent.ACTION_DRAG_EXITED -> {

                }
                DragEvent.ACTION_DROP -> {
                    animateDropEffect(v as ViewGroup, event.localState as View)
                }
                DragEvent.ACTION_DRAG_ENDED -> {

                }


                else -> {
                }
            }
            return true
        }


        private fun animateDropEffect(into: ViewGroup, view: View) {
            into.addView(view)
            val params = (view.layoutParams as FrameLayout.LayoutParams)
                    .apply {
                        gravity = Gravity.END
                    }
            view.layoutParams = params


        }

    }
}